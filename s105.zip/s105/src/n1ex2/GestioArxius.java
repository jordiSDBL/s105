package n1ex2;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GestioArxius {

	public static void main(String[] args) {
		// ruta que mirarem
		File directori = new File("C:\\Users\\jsedo\\Desktop\\tasca_S105");
		// cridem el m�tode recursiu
		fitxersRecursius(directori, " ");
	}

	public static void fitxersRecursius(File directori, String separador) {
		File[] fitxers = directori.listFiles();

		if (fitxers != null) {
			for (int i = 0; i < fitxers.length; i++) {
				// per capturar la data de modificaci� i aplicar-hi format
				long lastModified = fitxers[i].lastModified();
				String pattern = "yyyy-MM-dd hh:mm aa";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				Date lastModifiedDate = new Date(lastModified);
				// per afegir F o D en funci� del tipus d'arxiu
				char descripcio = 'F';
				if (fitxers[i].isDirectory()) {
					descripcio = 'D';
				}
				// impresi� de l'element
				System.out.println(separador + "(" + descripcio + ") " + fitxers[i].getName() + " ("
						+ simpleDateFormat.format(lastModifiedDate) + ")");
				// si directori, el m�tode es crida a ell mateix per repetir-ho internament
				if (fitxers[i].isDirectory()) {
					String sub_separador = separador + "\t";
					fitxersRecursius(fitxers[i], sub_separador);
				}
			}
		}
	}

	public static void lecturaDirectori(String str) {
		File directori = new File(str);
		String[] contingut_directori = directori.list();

		for (int i = 0; i < contingut_directori.length; i++) {
			System.out.println(contingut_directori[i]);
		}
	}
}
