package n1ex3;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GestioArxius {

	public static void main(String[] args) {
		/**
		 * Establim la ruta de treball i hi creem un arxiu de text buit preparat per la
		 * seg�ent acci�
		 */
		String ruta = "C:\\Users\\jsedo\\Desktop\\tasca_S105";
		crearArxiu(ruta + "\\index.txt");

		/**
		 * creem un objecte amb la ruta associada i cridem el m�tode recursiu per
		 * llista-ne el contingut i desar-lo dins d'un arxiu tipus text que passem per
		 * par�metre dins del m�tode escriureArxiu (cridat dins del m�tode
		 * fitxersRecursius).
		 */
		File directori = new File(ruta);
		fitxersRecursius(directori, " ", ruta);

	}

	public static void crearArxiu(String ruta) {
		// amb la classe File es crea un objecte de tipus File en mem�ria
		File arxiu = new File(ruta);
		try {
			// creem l'arxiu real amb la classe que hem generat
			PrintWriter salida = new PrintWriter(arxiu);
			salida.close(); // tanquem el proc�s, desant l'arxiu al disc dur del PC
			System.out.println("S'ha creat l'arxiu:");
		} catch (FileNotFoundException ex) {
			ex.printStackTrace(System.out);
		}
	}

	public static void escriureArxiu(String ruta, String contenido) {
		File arxiu = new File(ruta);
		try {
			// new FileWriter(archivo, true) perqu� sobreescrigui i no esborri
			PrintWriter salida = new PrintWriter(new FileWriter(arxiu, true));
			salida.println(contenido);
			salida.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace(System.out);
		} catch (IOException ex) { // ens obliga pel FileWriter()
			ex.printStackTrace(System.out);
		}
	}

	public static void fitxersRecursius(File directori, String separador, String ruta) {
		File[] fitxers = directori.listFiles();

		if (fitxers != null) {
			for (int i = 0; i < fitxers.length; i++) {
				// per capturar la data de modificaci� i aplicar-hi format
				long lastModified = fitxers[i].lastModified();
				String pattern = "yyyy-MM-dd hh:mm aa";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				Date lastModifiedDate = new Date(lastModified);
				// per afegir F o D en funci� del tipus d'arxiu
				char descripcio = 'F';
				if (fitxers[i].isDirectory()) {
					descripcio = 'D';
				}
				// contingut
				String contingut = separador + "(" + descripcio + ") " + fitxers[i].getName() + " ("
						+ simpleDateFormat.format(lastModifiedDate) + ")";
				// escriure la cadena a dins de l'arxiu
				escriureArxiu(ruta + "\\index.txt", contingut);
				// impresi� del text per consola
				System.out.println(contingut);
				// si es un directori, el m�tode es crida a ell mateix
				if (fitxers[i].isDirectory()) {
					String sub_separador = separador + "\t";
					fitxersRecursius(fitxers[i], sub_separador, ruta);
				}
			}
		}
	}
	
	public static void lecturaDirectori(String str) {
		File directori = new File(str);
		String[] contingut_directori = directori.list();

		for (int i = 0; i < contingut_directori.length; i++) {
			System.out.println(contingut_directori[i]);
		}
	}
}