package n1ex5;

import java.io.Serializable;

public class Persona implements Serializable {
	/**
	 * generem un n�mero indentificatiu SHA per autoritzar la deserialitzaci� nom�s
	 * en el cas que el receptor tingui una versi� exacte del programa que l'emisor
	 * ha enviat o b�, encar que sigui una altra versi�, que mantingui el mateix
	 * n�mero identificatiu
	 */
	private static final long serialVersionUID = -2261746968176982378L;

	// atributs
	String nom, dni, tel, ae;
	int edat;
	char genere;

	// constructor
	public Persona(String nom, String dni, String tel, String ae, int edat, char genere) {
		this.nom = nom;
		this.dni = dni;
		this.tel = tel;
		this.ae = ae;
		this.edat = edat;
		this.genere = genere;
	}

	// getters i setters
	public String getNom() {return nom;}
	public void setNom(String nom) {this.nom = nom;}
	public String getDni() {return dni;}
	public void setDni(String dni) {this.dni = dni;}
	public String getTel() {return tel;}
	public void setTel(String tel) {this.tel = tel;}
	public String getAe() {return ae;}
	public void setAe(String ae) {this.ae = ae;}
	public int getEdat() {return edat;}
	public void setEdat(int edat) {this.edat = edat;}
	public char getGenere() {return genere;}
	public void setGenere(char genere) {this.genere = genere;}

	// toString
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Persona:\nnom = ");
		builder.append(nom);
		builder.append("\ndni =  ");
		builder.append(dni);
		builder.append("\ntel = ");
		builder.append(tel);
		builder.append("\na.e. = ");
		builder.append(ae);
		builder.append("\nedat = ");
		builder.append(edat);
		builder.append("\ngenere = ");
		builder.append(genere);
		return builder.toString();
	}
}
