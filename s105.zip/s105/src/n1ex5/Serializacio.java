package n1ex5;

import java.io.*;

public class Serializacio {
	public static void main(String[] args) {
		String ruta = "C:\\Users\\jsedo\\Desktop\\tasca_S105\\serialitzacio\\personal.txt";
		Persona persona1 = new Persona("Marc", "47885514L", "654218740", "marcpr@gmail.com", 40, 'H');

		try {
			/**
			 * serialitzaci�
			 */
			// creem el fluxe de dades extern
			ObjectOutputStream escrivint = new ObjectOutputStream(new FileOutputStream(ruta));
			// escribir l'objecte
			escrivint.writeObject(persona1);
			escrivint.close(); // tanquem el fluxe

			/**
			 * deserializaci�
			 */
			// creem el fluxe de dades d'entrada
			ObjectInputStream recuperant = new ObjectInputStream(new FileInputStream(ruta));
			// llegim l'objecte i l'emmagatzemem en un objecte de la mateixa classe
			Persona persona_recuperada = (Persona) recuperant.readObject();
			recuperant.close(); // tanquem el fluxe

			// imprimim per consola per veure que s'ha recuperat correctament la informaci�
			System.out.println(persona_recuperada);

		} catch (Exception e) {
			System.out.println("Error. No s'ha dut a terme el proc�s.");
		}
	}
}
