package n1ex4;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GestioArxius {

	public static void main(String[] args) {
		/**
		 * Establim la ruta de treball i hi creem un arxiu de text buit preparat per la
		 * seg�ent acci�
		 */
		String ruta = "C:\\Users\\jsedo\\Desktop\\tasca_S105";
		crearArxiu(ruta + "\\index.txt");

		/**
		 * creem un objecte amb la ruta associada i cridem el m�tode recursiu per
		 * llista-ne el contingut i desar-lo dins d'un arxiu tipus text que passem per
		 * par�metre dins del m�tode escriureArxiu (cridat dins del m�tode
		 * fitxersRecursius).
		 */
		File directori = new File(ruta);
		fitxersRecursius(directori, " ", ruta);

		/**
		 * Cridem el m�tode per llegir l�nia a l�nia el contingut d'un fitxer i
		 * imprimir-ho per consola
		 */
		llegirArxiu(ruta + "\\index.txt");
	}

	public static void llegirArxiu(String nombreArchivo) {
		File arxiu = new File(nombreArchivo);
		try {
			BufferedReader entrada = new BufferedReader(new FileReader(arxiu));
			String lectura = entrada.readLine();
			System.out.println("\nLECTURA DE L'ARXIU");
			while (lectura != null) {
				System.out.println("-- " + lectura);
				lectura = entrada.readLine();
			}
			entrada.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace(System.out);
		} catch (IOException ex) {
			ex.printStackTrace(System.out);
		}
	}

	public static void crearArxiu(String ruta) {
		// amb la classe File es crea un objecte de tipus File en mem�ria
		File arxiu = new File(ruta);
		try {
			// creem l'arxiu real amb la classe que hem generat
			PrintWriter salida = new PrintWriter(arxiu);
			salida.close(); // tanquem el proc�s, desant l'arxiu al disc dur del PC
			System.out.println("S'ha creat l'arxiu:");
		} catch (FileNotFoundException ex) {
			ex.printStackTrace(System.out);
		}
	}

	public static void escriureArxiu(String ruta, String contenido) {
		File arxiu = new File(ruta);
		try {
			// new FileWriter(archivo, true) perqu� sobreescrigui i no esborri
			PrintWriter salida = new PrintWriter(new FileWriter(arxiu, true));
			salida.println(contenido);
			salida.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace(System.out);
		} catch (IOException ex) { // ens obliga pel FileWriter()
			ex.printStackTrace(System.out);
		}
	}

	public static void fitxersRecursius(File directorio, String separador, String ruta) {
		File[] ficheros = directorio.listFiles();

		if (ficheros != null) {
			for (int x = 0; x < ficheros.length; x++) {
				// per capturar la data de modificaci� i aplicar-hi format
				long lastModified = ficheros[x].lastModified();
				String pattern = "yyyy-MM-dd hh:mm aa";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				Date lastModifiedDate = new Date(lastModified);
				// per afegir F o D en funci� del tipus d'arxiu
				char descripcio = 'F';
				if (ficheros[x].isDirectory()) {
					descripcio = 'D';
				}
				// contingut
				String contingut = separador + "(" + descripcio + ") " + ficheros[x].getName() + " ("
						+ simpleDateFormat.format(lastModifiedDate) + ")";
				// escriure la cadena a dins de l'arxiu
				escriureArxiu(ruta + "\\index.txt", contingut);
				// impresi� del text per consola
				System.out.println(contingut);
				// si es un directori, el m�tode es crida a ell mateix
				if (ficheros[x].isDirectory()) {
					String nuevo_separador = separador + "\t";
					fitxersRecursius(ficheros[x], nuevo_separador, ruta);
				}
			}
		}
	}

	public static void lecturaDirectori(String str) {
		File directori = new File(str);
		String[] contingut_directori = directori.list();

		for (int i = 0; i < contingut_directori.length; i++) {
			System.out.println(contingut_directori[i]);
		}
	}
}