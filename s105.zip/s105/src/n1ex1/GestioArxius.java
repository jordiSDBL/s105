package n1ex1;

import java.io.File;

public class GestioArxius {

	public static void main(String[] args) {
		// quina directori llistarem?
		String ruta = "C:\\Users\\jsedo\\Desktop\\tasca_S105";
		
		//cridem el m�tode i ho llista en ordre alfab�tic
		lecturaDirectori(ruta);
	}
	
	public static void lecturaDirectori(String str) {
		File directori = new File(str);
		String[] contingut_directori = directori.list();

		for (int i = 0; i < contingut_directori.length; i++) {
			System.out.println(contingut_directori[i]);
		}
	}
}
